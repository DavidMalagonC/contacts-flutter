class Texts {
    Texts._();
    static const String myContacts = "My contacts";
    static const String save = "Save";
    static const String delete = "Delete";
    static const String edit = "Edit";
    static const String name = "Name";
    static const String email = "Email";
    static const String number = "Number";
}