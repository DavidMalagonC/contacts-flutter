import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:contacts_flutter/features/contacts/models/contact.dart';
import 'package:contacts_flutter/features/contacts/usecases/contacts_use_cases.dart';
import 'package:flutter/material.dart';

part 'contacts_event.dart';
part 'contacts_state.dart';

class ContactsBloc extends Bloc<ContactsEvent, ContactsState> {
  final ContactsUsesCases usesCases;

  ContactsBloc(this.usesCases) : super(ContactsStateInitial()) {
    on<OnContacts>(onKeyContent);
  }

  FutureOr<void> onKeyContent(
    OnContacts event,
    Emitter<ContactsState> emit,
  ) async {
    emit(ContactsLoadingState(state.dataContacts));
    final res = await usesCases.getContactsUseCase.invoke();
    res.fold(
        (l) => emit(ContactsErrorState(
              state.dataContacts,
            )),
        (list) => emit(ContactsInformationState(
              state.dataContacts.copyWith(contactList: list),
            )));
  }
}
