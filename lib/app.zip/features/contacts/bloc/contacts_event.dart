part of 'contacts_bloc.dart';

@immutable
abstract class ContactsEvent {}

class OnContacts implements ContactsEvent {
  OnContacts();
}