import 'package:contacts_flutter/features/contacts/usecases/get_contacts_use_case.dart';

class ContactsUsesCases {
  final GetContactsUseCase getContactsUseCase;
  //final SaveContactUseCase getTitleUseCase;

  ContactsUsesCases(
    this.getContactsUseCase
  );
}