abstract class DI {
  Future<void> initialize();
}