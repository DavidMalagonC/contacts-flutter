import 'package:flutter/material.dart';

final Map<String, Widget Function(BuildContext)> routes = {
  //MyHomePage.path: (_) => const MyHomePage(),
};